package com.example.fort_macarthur

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
